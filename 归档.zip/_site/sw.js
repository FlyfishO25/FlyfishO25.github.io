var CACHE = 'cache-and-update';

var urlsToCache = [
  
    
      '/403.html',
    
  
    
       
    
  
    
      '/category/Living.html',
    
  
    
      '/category/',
    
  
    
      '/editor/',
    
  
    
      '/friends/',
    
  
    
      '/assets/css/global.css',
    
  
    
      '/',
    
  
    
      '/love/',
    
  
    
      '/search.json',
    
  
    
      '/sw.js',
    
  
    
      '/tags/',
    
  
    
      '/tags.json',
    
  
    
      '/category/technology.html',
    
  
    
      '/sitemap.xml',
    
  
    
      '/robots.txt',
    
  
    
      '/feed.xml',
    
  

  
    '/technology/2021/05/03/Create-New-Blog.html',
  

  
    '/CHANGELOG.md',
  
    '/README 2.md',
  
    '/assets/css/customCss.css',
  
    '/assets/images/touch/apple-touch-icon.png',
  
    '/assets/images/touch/chrome-touch-icon-192x192.png',
  
    '/assets/images/touch/icon-128x128.png',
  
    '/assets/images/touch/ms-touch-icon-144x144-precomposed.png',
  
    '/assets/js/History.js',
  
    '/assets/js/customJS.js',
  
    '/jekylltheme.jpg',
  
    '/manifest.json',
  
];

self.addEventListener('install', function(evt) {
  evt.waitUntil(caches.open(CACHE).then(function(cache) {
    cache.addAll(urlsToCache);
  }));
});

self.addEventListener('fetch', function(evt) {
  evt.respondWith(fromCache(evt.request));
  evt.waitUntil(update(evt.request));
});

function fromCache(request) {
  return caches.open(CACHE).then(function(cache) {
    return cache.match(request).then(function(response) {
      if (response != undefined) {
        return response;
      } else {
        return fetchFromInternet(request);
      }
    });
  }).catch(function() {
    return caches.match('/offline.html');
  });
}

function update(request) {
  return caches.open(CACHE).then(function(cache) {
    return fetchFromInternet(request);
  });
}

function fetchFromInternet(request) {
  var fetchRequset = request.clone();
  return fetch(fetchRequset).then(function(response) {
    if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
    }
    var responseToCache = response.clone();
    caches.open(CACHE).then(function(cache) {
      cache.put(request, responseToCache);
    });
    return response;
  });
}
