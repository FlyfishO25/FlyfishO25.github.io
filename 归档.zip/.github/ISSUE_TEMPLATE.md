
**I certify that I have first consulted** (check all with "x")

- [ ] [Jekyll documentation ](https://jekyllrb.com/)
- [ ] [jekyll-theme-mdui documentation ](http://mdui.kejun.me/#/)
- [ ] [jekyll-theme-mdui issues ](https://github.com/KeJunMao/jekyll-theme-mdui/issues)

----

**I'm submitting a**  (check one with "x")

- [ ] bug report
- [ ] feature request
- [ ] support request
