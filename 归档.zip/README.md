# README
this is my PERSOMAL blog resp. .
