<style>
  section.cover.show .cover-main{
    color: #fff;
  }
  section.cover.show h1 span{
    color: #fff!important;
  }
  .app-nav a.active{
    color: white;
    text-shadow: 0px 0px 2px #000;
  }
  .app-nav a{
    color: white;
    text-shadow: 0px 0px 2px #000;
  }
</style>
![logo](_media/icon.png)

# Jekyll Theme MDUI

> Material Design

- Simple
- Based on MDUI

![color](#01897b)