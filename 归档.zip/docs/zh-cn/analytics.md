# 数据统计于分析

我们主题支持Google analytics。

## 如何使用

要启用 Google analytics 只需在`_data/site.yml`找到 `google_analytics:` 字段，填入自己的信息即可。

```yaml
google_analytics: ""  # google analytics code
```