# fastjekyll

该工具可以帮助你在win环境快速安装jekyll。

[github](https://github.com/KeJunMao/fastjekyll)